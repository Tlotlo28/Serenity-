// Global state
let soundEnabled = false;
let isLoading = false;
let currentUser = null;
let messageHistory = [];

// DOM Elements
const splashScreen = document.getElementById('splash-screen');
const authScreen = document.getElementById('auth-screen');
const mainApp = document.getElementById('main-app');
const motivationText = document.getElementById('motivation-text');
const chatMessages = document.getElementById('chat-messages');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const soundToggle = document.getElementById('sound-toggle');
const soundIcon = document.getElementById('sound-icon');

// Auth elements
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');
const loginBtn = document.getElementById('login-btn');
const registerBtn = document.getElementById('register-btn');
const continueGuest = document.getElementById('continue-guest');
const showRegister = document.getElementById('show-register');
const showLogin = document.getElementById('show-login');
const authError = document.getElementById('auth-error');
const logoutBtn = document.getElementById('logout-btn');
const userDisplay = document.getElementById('user-display');

// Resource elements
const toggleResources = document.getElementById('toggle-resources');
const resourcesPanel = document.getElementById('resources-panel');
const resourcesList = document.getElementById('resources-list');
const saveConvoBtn = document.getElementById('save-convo-btn');

// Modal elements
const resourceModal = document.getElementById('resource-modal');
const modalTitle = document.getElementById('modal-title');
const modalBody = document.getElementById('modal-body');
const closeModal = document.getElementById('close-modal');

// Initialize app
async function init() {
    console.log('🚀 Initializing app...');
    
    // Load motivation quote
    await loadMotivation();
    
    // Load mental health resources
    await loadMentalHealthResources();
    
    // Show splash for 3.5 seconds, then auth screen
    setTimeout(async () => {
        console.log('✅ Hiding splash screen');
        splashScreen.style.display = 'none';
        
        // Check if user is already logged in
        const authStatus = await checkAuth();
        if (authStatus.authenticated) {
            currentUser = authStatus.username;
            showMainApp();
        } else {
            authScreen.classList.remove('hidden');
        }
    }, 3500);
    
    // Event listeners
    sendButton.addEventListener('click', sendMessage);
    messageInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            sendMessage();
        }
    });
    
    soundToggle.addEventListener('click', toggleSound);
    loginBtn.addEventListener('click', handleLogin);
    registerBtn.addEventListener('click', handleRegister);
    continueGuest.addEventListener('click', handleGuestMode);
    showRegister.addEventListener('click', () => {
        loginForm.classList.add('hidden');
        registerForm.classList.remove('hidden');
        authError.classList.add('hidden');
    });
    showLogin.addEventListener('click', () => {
        registerForm.classList.add('hidden');
        loginForm.classList.remove('hidden');
        authError.classList.add('hidden');
    });
    logoutBtn.addEventListener('click', handleLogout);
    
    toggleResources.addEventListener('click', () => {
        resourcesPanel.classList.toggle('hidden');
    });
    
    saveConvoBtn.addEventListener('click', saveConversation);
    closeModal.addEventListener('click', () => {
        resourceModal.classList.add('hidden');
    });
}

// Auth functions
async function checkAuth() {
    try {
        const response = await fetch('/api/check-auth');
        return await response.json();
    } catch (error) {
        console.error('Auth check error:', error);
        return { authenticated: false };
    }
}

async function handleLogin() {
    const username = document.getElementById('login-username').value.trim();
    const password = document.getElementById('login-password').value;
    
    if (!username || !password) {
        showAuthError('Please enter username and password');
        return;
    }
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.username;
            showMainApp();
        } else {
            showAuthError(data.error || 'Login failed');
        }
    } catch (error) {
        console.error('Login error:', error);
        showAuthError('Connection error. Please try again.');
    }
}

async function handleRegister() {
    const username = document.getElementById('register-username').value.trim();
    const password = document.getElementById('register-password').value;
    
    if (!username || !password) {
        showAuthError('Please enter username and password');
        return;
    }
    
    if (password.length < 4) {
        showAuthError('Password must be at least 4 characters');
        return;
    }
    
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.username;
            showMainApp();
        } else {
            showAuthError(data.error || 'Registration failed');
        }
    } catch (error) {
        console.error('Register error:', error);
        showAuthError('Connection error. Please try again.');
    }
}

function handleGuestMode() {
    currentUser = null;
    showMainApp();
}

async function handleLogout() {
    try {
        await fetch('/api/logout', { method: 'POST' });
        currentUser = null;
        messageHistory = [];
        chatMessages.innerHTML = '';
        mainApp.classList.add('hidden');
        authScreen.classList.remove('hidden');
    } catch (error) {
        console.error('Logout error:', error);
    }
}

function showAuthError(message) {
    authError.textContent = message;
    authError.classList.remove('hidden');
    setTimeout(() => {
        authError.classList.add('hidden');
    }, 3000);
}

function showMainApp() {
    authScreen.classList.add('hidden');
    mainApp.classList.remove('hidden');
    mainApp.style.opacity = '1';
    
    if (currentUser) {
        userDisplay.textContent = `👤 ${currentUser}`;
        logoutBtn.classList.remove('hidden');
    } else {
        userDisplay.textContent = '👤 guest';
        logoutBtn.classList.add('hidden');
    }
    
    addMessage('assistant', "Hello, I'm here to listen. This is a safe space where you can share what's on your mind. How are you feeling today?");
}

// Load motivational quote
async function loadMotivation() {
    try {
        console.log('📖 Loading motivation quote...');
        const response = await fetch('/api/motivation');
        const data = await response.json();
        motivationText.textContent = `"${data.quote}"`;
    } catch (error) {
        console.error('Error loading motivation:', error);
        motivationText.textContent = '"You are stronger than you know. Take it one moment at a time."';
    }
}

// Load mental health resources
async function loadMentalHealthResources() {
    try {
        const response = await fetch('/api/mental-health-issues');
        const data = await response.json();
        
        resourcesList.innerHTML = '';
        data.issues.forEach(issue => {
            const button = document.createElement('button');
            button.className = 'resource-item';
            button.textContent = issue.label;
            button.addEventListener('click', () => showResourceModal(issue.id));
            resourcesList.appendChild(button);
        });
    } catch (error) {
        console.error('Error loading resources:', error);
    }
}

// Show resource modal
async function showResourceModal(issueId) {
    try {
        const response = await fetch(`/api/mental-health-solution/${issueId}`);
        const data = await response.json();
        
        modalTitle.textContent = data.title;
        
        let html = '<h3>💡 helpful strategies</h3><ul>';
        data.solutions.forEach(solution => {
            html += `<li>${solution}</li>`;
        });
        html += '</ul>';
        
        html += '<h3>📅 suggested routine</h3>';
        html += `<div class="routine-box">${data.routine}</div>`;
        
        modalBody.innerHTML = html;
        resourceModal.classList.remove('hidden');
    } catch (error) {
        console.error('Error loading solution:', error);
    }
}

// Save conversation
async function saveConversation() {
    if (!currentUser) {
        alert('Please sign in to save conversations');
        return;
    }
    
    if (messageHistory.length === 0) {
        alert('No conversation to save');
        return;
    }
    
    try {
        const response = await fetch('/api/save-conversation', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ messages: messageHistory })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            alert('✅ Conversation saved successfully!');
        } else {
            alert('Failed to save conversation');
        }
    } catch (error) {
        console.error('Save error:', error);
        alert('Error saving conversation');
    }
}

// Add message to chat
function addMessage(role, content) {
    console.log(`💬 Adding ${role} message`);
    
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}`;
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'message-bubble';
    bubbleDiv.innerHTML = content.replace(/\n/g, '<br>');
    
    messageDiv.appendChild(bubbleDiv);
    chatMessages.appendChild(messageDiv);
    
    // Save to history
    messageHistory.push({ role, content });
    
    scrollToBottom();
}

// Add loading indicator
function addLoadingIndicator() {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message assistant loading';
    messageDiv.id = 'loading-indicator';
    
    const bubbleDiv = document.createElement('div');
    bubbleDiv.className = 'message-bubble';
    
    for (let i = 0; i < 3; i++) {
        const dot = document.createElement('div');
        dot.className = 'loading-dot';
        bubbleDiv.appendChild(dot);
    }
    
    messageDiv.appendChild(bubbleDiv);
    chatMessages.appendChild(messageDiv);
    scrollToBottom();
}

// Remove loading indicator
function removeLoadingIndicator() {
    const loader = document.getElementById('loading-indicator');
    if (loader) loader.remove();
}

// Send message
async function sendMessage() {
    const message = messageInput.value.trim();
    
    if (!message || isLoading) return;
    
    console.log('📤 Sending message:', message);
    
    addMessage('user', message);
    messageInput.value = '';
    
    isLoading = true;
    sendButton.disabled = true;
    addLoadingIndicator();
    
    try {
        const response = await fetch('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message })
        });
        
        const data = await response.json();
        removeLoadingIndicator();
        
        if (response.ok) {
            addMessage('assistant', data.response);
            
            if (data.crisis_detected) {
                setTimeout(() => {
                    addMessage('crisis', '🆘 If you\'re in crisis, please reach out now:\n• SADAG: 0800 567 567\n• Lifeline: 0861 322 322\n• Suicide Crisis Line: 0800 567 567');
                }, 1000);
            }
        } else {
            addMessage('assistant', data.response || data.error || 'I apologize, I\'m having trouble connecting right now.');
        }
    } catch (error) {
        console.error('Error:', error);
        removeLoadingIndicator();
        addMessage('assistant', "I'm having trouble connecting right now. If you need immediate support, please contact one of the helplines below.");
    } finally {
        isLoading = false;
        sendButton.disabled = false;
        messageInput.focus();
    }
}

// Toggle sound
function toggleSound() {
    soundEnabled = !soundEnabled;
    soundIcon.textContent = soundEnabled ? '🔊' : '🔇';
}

// Scroll to bottom
function scrollToBottom() {
    setTimeout(() => {
        const container = chatMessages.parentElement;
        if (container) {
            container.scrollTop = container.scrollHeight;
        }
    }, 100);
}

// Start the app
console.log('🎬 Starting Serenity app...');
init();