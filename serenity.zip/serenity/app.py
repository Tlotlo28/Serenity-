from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
import os
from dotenv import load_dotenv
import json
from datetime import datetime
import secrets
import sqlite3
import hashlib

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.secret_key = secrets.token_hex(16)
CORS(app)

# Database setup
DATABASE = 'serenity.db'

def get_db():
    """Get database connection"""
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Initialize database tables"""
    conn = get_db()
    cursor = conn.cursor()
    
    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Conversations table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS conversations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            messages TEXT NOT NULL,
            saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    conn.commit()
    conn.close()
    print("✅ Database initialized")

def hash_password(password):
    """Hash password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()

# Initialize AI clients
use_groq = os.getenv('USE_GROQ', 'false').lower() == 'true'
ai_client = None
ai_provider = None

if use_groq:
    # Try Groq first (free!)
    groq_key = os.getenv('GROQ_API_KEY')
    if groq_key:
        try:
            from groq import Groq
            ai_client = Groq(api_key=groq_key)
            ai_provider = 'groq'
            print("✅ Using Groq AI (Free) - Model: llama-3.1-70b-versatile")
        except ImportError:
            print("❌ Groq library not installed. Run: pip install groq")
        except Exception as e:
            print(f"❌ Error initializing Groq: {e}")
    else:
        print("⚠️  GROQ_API_KEY not found in .env")
else:
    # Use Anthropic (requires credits)
    anthropic_key = os.getenv('ANTHROPIC_API_KEY')
    if anthropic_key:
        try:
            from anthropic import Anthropic
            ai_client = Anthropic(api_key=anthropic_key)
            ai_provider = 'anthropic'
            print("✅ Using Anthropic Claude AI")
        except ImportError:
            print("❌ Anthropic library not installed. Run: pip install anthropic")
        except Exception as e:
            print(f"❌ Error initializing Anthropic: {e}")
    else:
        print("❌ ANTHROPIC_API_KEY not found in .env")

if not ai_client:
    print("\n" + "="*60)
    print("⚠️  NO AI CLIENT CONFIGURED!")
    print("="*60)
    print("\nPlease add to your .env file:")
    print("\nOption 1 - Free Groq:")
    print("  GROQ_API_KEY=gsk_your_key_here")
    print("  USE_GROQ=true")
    print("  Get key: https://console.groq.com/keys")
    print("\nOption 2 - Anthropic Claude (requires credits):")
    print("  ANTHROPIC_API_KEY=sk-ant-your_key_here")
    print("  USE_GROQ=false")
    print("="*60 + "\n")

# Motivational quotes
MOTIVATIONAL_QUOTES = [
    "You are stronger than you know. Take it one moment at a time.",
    "Healing is not linear. Be gentle with yourself today.",
    "Your feelings are valid. It's okay to not be okay sometimes.",
    "Small steps forward are still progress. You're doing great.",
    "You deserve kindness, especially from yourself.",
    "This too shall pass. Brighter days are coming.",
    "Your mental health matters. Taking time for yourself is not selfish.",
    "Every day may not be good, but there is good in every day.",
]

# Mental health issues and solutions
MENTAL_HEALTH_ISSUES = {
    "anxiety": {
        "title": "Anxiety Management",
        "solutions": [
            "Practice deep breathing: 4-7-8 technique (inhale 4s, hold 7s, exhale 8s)",
            "Ground yourself with the 5-4-3-2-1 method (5 things you see, 4 you hear, etc.)",
            "Regular exercise: 30 minutes daily can reduce anxiety by 50%",
            "Limit caffeine and alcohol consumption",
            "Establish a consistent sleep schedule (7-9 hours)"
        ],
        "routine": "Morning: 10-min meditation → Throughout day: Deep breathing when anxious → Evening: Journaling worries → Night: Relaxing routine (no screens 1hr before bed)"
    },
    "depression": {
        "title": "Depression Support",
        "solutions": [
            "Set small, achievable daily goals (even just making your bed counts)",
            "Get sunlight exposure: 15-30 minutes daily",
            "Connect with someone, even briefly (text, call, or in-person)",
            "Move your body: Even a 10-minute walk can help",
            "Practice self-compassion: Treat yourself like you'd treat a friend"
        ],
        "routine": "Morning: Open curtains for sunlight, small breakfast → Midday: 15-min walk outside → Afternoon: One meaningful task → Evening: Connect with someone → Night: Acknowledge one thing that went okay today"
    },
    "stress": {
        "title": "Stress Management",
        "solutions": [
            "Break tasks into smaller, manageable chunks",
            "Use the Pomodoro Technique: 25 min work, 5 min break",
            "Practice progressive muscle relaxation",
            "Say 'no' to additional commitments when overwhelmed",
            "Create a 'worry time': 15 minutes daily to address concerns"
        ],
        "routine": "Morning: List top 3 priorities → Throughout day: Take 5-min breaks every hour → Afternoon: Physical activity → Evening: 10-min worry time → Night: Prepare tomorrow's to-do list"
    },
    "insomnia": {
        "title": "Sleep Improvement",
        "solutions": [
            "Keep consistent sleep/wake times (even weekends)",
            "Create a relaxing bedtime routine (30-60 minutes)",
            "Keep bedroom cool (60-67°F/15-19°C), dark, and quiet",
            "Avoid screens 1 hour before bed (blue light disrupts melatonin)",
            "Only use bed for sleep (not work or TV)"
        ],
        "routine": "9:00 PM: No more screens → 9:30 PM: Dim lights, relaxing activity → 10:00 PM: Bedroom routine → 10:30 PM: Bed at same time daily → Morning: Wake same time, get sunlight immediately"
    },
    "loneliness": {
        "title": "Building Connection",
        "solutions": [
            "Join a group or club based on your interests",
            "Volunteer in your community",
            "Reach out to one person daily (text, call, or meet)",
            "Practice self-compassion: You're not alone in feeling alone",
            "Consider online communities for your hobbies"
        ],
        "routine": "Morning: Send a good morning message to someone → Midday: Engage in community (online or in-person) → Afternoon: Activity outside home → Evening: Video call or meet someone → Night: Reflect on positive interactions"
    },
    "low_self_esteem": {
        "title": "Building Self-Worth",
        "solutions": [
            "Keep a daily wins journal (even small accomplishments)",
            "Challenge negative self-talk: Ask 'Would I say this to a friend?'",
            "Set boundaries and practice saying 'no'",
            "Focus on effort, not just outcomes",
            "Celebrate progress, not perfection"
        ],
        "routine": "Morning: One positive affirmation → Throughout day: Notice negative self-talk, reframe it → Afternoon: Do something you're good at → Evening: Write 3 things you did well → Night: Self-care activity"
    }
}

@app.route('/')
def home():
    """Serve the main page"""
    return render_template('index.html')

@app.route('/api/motivation', methods=['GET'])
def get_motivation():
    """Get a random motivational quote"""
    import random
    return jsonify({'quote': random.choice(MOTIVATIONAL_QUOTES)})

@app.route('/api/mental-health-issues', methods=['GET'])
def get_mental_health_issues():
    """Get list of mental health issues"""
    return jsonify({
        'issues': [
            {'id': 'anxiety', 'label': 'Anxiety & Panic'},
            {'id': 'depression', 'label': 'Depression & Low Mood'},
            {'id': 'stress', 'label': 'Stress & Overwhelm'},
            {'id': 'insomnia', 'label': 'Sleep Problems'},
            {'id': 'loneliness', 'label': 'Loneliness & Isolation'},
            {'id': 'low_self_esteem', 'label': 'Low Self-Esteem'}
        ]
    })

@app.route('/api/mental-health-solution/<issue_id>', methods=['GET'])
def get_mental_health_solution(issue_id):
    """Get solution for specific mental health issue"""
    if issue_id in MENTAL_HEALTH_ISSUES:
        return jsonify(MENTAL_HEALTH_ISSUES[issue_id])
    return jsonify({'error': 'Issue not found'}), 404

@app.route('/api/register', methods=['POST'])
def register():
    """Register a new user"""
    data = request.json
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    if len(password) < 4:
        return jsonify({'error': 'Password must be at least 4 characters'}), 400
    
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        password_hash = hash_password(password)
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)',
                      (username, password_hash))
        conn.commit()
        conn.close()
        
        session['username'] = username
        return jsonify({'success': True, 'username': username})
    except sqlite3.IntegrityError:
        return jsonify({'error': 'Username already exists'}), 400
    except Exception as e:
        print(f"Registration error: {e}")
        return jsonify({'error': 'Registration failed'}), 500

@app.route('/api/login', methods=['POST'])
def login():
    """Login user"""
    data = request.json
    username = data.get('username', '').strip()
    password = data.get('password', '')
    
    if not username or not password:
        return jsonify({'error': 'Username and password required'}), 400
    
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        password_hash = hash_password(password)
        cursor.execute('SELECT id FROM users WHERE username = ? AND password_hash = ?',
                      (username, password_hash))
        user = cursor.fetchone()
        conn.close()
        
        if not user:
            return jsonify({'error': 'Invalid username or password'}), 401
        
        session['username'] = username
        session['user_id'] = user[0]
        return jsonify({'success': True, 'username': username})
    except Exception as e:
        print(f"Login error: {e}")
        return jsonify({'error': 'Login failed'}), 500

@app.route('/api/logout', methods=['POST'])
def logout():
    """Logout user"""
    session.clear()
    return jsonify({'success': True})

@app.route('/api/check-auth', methods=['GET'])
def check_auth():
    """Check if user is authenticated"""
    username = session.get('username')
    return jsonify({
        'authenticated': username is not None,
        'username': username
    })

@app.route('/api/save-conversation', methods=['POST'])
def save_conversation():
    """Save conversation history"""
    username = session.get('username')
    user_id = session.get('user_id')
    
    if not username or not user_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    data = request.json
    messages = data.get('messages', [])
    
    if not messages:
        return jsonify({'error': 'No messages to save'}), 400
    
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        messages_json = json.dumps(messages)
        cursor.execute('INSERT INTO conversations (user_id, messages) VALUES (?, ?)',
                      (user_id, messages_json))
        conversation_id = cursor.lastrowid
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'success': True,
            'conversation_id': conversation_id,
            'message': 'Conversation saved successfully'
        })
    except Exception as e:
        print(f"Save conversation error: {e}")
        return jsonify({'error': 'Failed to save conversation'}), 500

@app.route('/api/get-conversations', methods=['GET'])
def get_conversations():
    """Get user's saved conversations"""
    username = session.get('username')
    user_id = session.get('user_id')
    
    if not username or not user_id:
        return jsonify({'error': 'Not authenticated'}), 401
    
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, messages, saved_at 
            FROM conversations 
            WHERE user_id = ? 
            ORDER BY saved_at DESC
        ''', (user_id,))
        
        rows = cursor.fetchall()
        conn.close()
        
        conversations = []
        for row in rows:
            conversations.append({
                'id': row[0],
                'messages': json.loads(row[1]),
                'saved_at': row[2]
            })
        
        return jsonify({'conversations': conversations})
    except Exception as e:
        print(f"Get conversations error: {e}")
        return jsonify({'error': 'Failed to retrieve conversations'}), 500

@app.route('/api/chat', methods=['POST'])
def chat():
    """Handle chat messages"""
    try:
        if not ai_client:
            error_msg = "No AI service configured. Please add API key to .env file."
            print(f"❌ {error_msg}")
            return jsonify({
                'error': 'AI not configured',
                'response': "The chatbot AI service is not configured. Please check the .env file and add either GROQ_API_KEY or ANTHROPIC_API_KEY."
            }), 500
        
        data = request.json
        user_message = data.get('message', '')
        
        if not user_message:
            return jsonify({'error': 'No message provided'}), 400
        
        print(f"📥 Received message: {user_message[:50]}...")
        
        # Check for crisis keywords
        crisis_keywords = ['suicide', 'kill myself', 'end it all', 'want to die', 'hurt myself']
        contains_crisis = any(keyword in user_message.lower() for keyword in crisis_keywords)
        
        # Construct the system prompt
        system_prompt = """You are Serenity, a compassionate and empathetic AI therapy companion. 

Your role is to:
- Listen actively and validate emotions without judgment
- Use reflective listening techniques
- Ask gentle, open-ended questions to help users explore their feelings
- Provide evidence-based coping strategies when appropriate
- Always encourage professional help for serious mental health issues
- Be warm, supportive, and genuine in your responses

Communication style:
- Keep responses conversational and concise (2-4 short paragraphs)
- Use a warm, friendly tone
- Show empathy and understanding
- Avoid being overly clinical or robotic
- Focus on the person's feelings and experiences

Always prioritize the user's wellbeing and emotional safety."""

        if contains_crisis:
            system_prompt += "\n\nURGENT: The user mentioned something concerning related to self-harm or suicide. Respond with deep compassion and empathy, but immediately and strongly encourage them to reach out to a professional crisis helpline. Their safety is the top priority."
        
        print(f"🤖 Calling {ai_provider.upper()} API...")
        
        # Call appropriate AI API
        if ai_provider == 'groq':
            response = ai_client.chat.completions.create(
                model="llama-3.1-70b-versatile",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message}
                ],
                max_tokens=1000,
                temperature=0.7
            )
            response_text = response.choices[0].message.content
            
        elif ai_provider == 'anthropic':
            response = ai_client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=1000,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": user_message}
                ]
            )
            response_text = response.content[0].text
        
        print(f"✅ API response received: {response_text[:100]}...")
        
        return jsonify({
            'response': response_text,
            'crisis_detected': contains_crisis
        })
        
    except Exception as e:
        error_msg = str(e)
        print(f"❌ Error in chat endpoint: {error_msg}")
        
        # Provide specific error messages
        if "api_key" in error_msg.lower() or "authentication" in error_msg.lower():
            return jsonify({
                'error': 'Authentication error',
                'response': "There's an issue with the API key. Please verify it's correct in the .env file."
            }), 500
        elif "rate_limit" in error_msg.lower():
            return jsonify({
                'error': 'Rate limit',
                'response': "Too many requests. Please wait a moment before trying again."
            }), 429
        elif "credit" in error_msg.lower() or "billing" in error_msg.lower():
            return jsonify({
                'error': 'No credits',
                'response': "The AI service has no credits remaining. Please add credits or switch to a free alternative."
            }), 500
        else:
            return jsonify({
                'error': 'Service error',
                'response': f"Connection error. If you need immediate support, please contact the helplines below."
            }), 500

if __name__ == '__main__':
    # Initialize database
    print("\n🗄️  Initializing database...")
    init_db()
    
    # Display AI configuration
    print("\n" + "="*60)
    print("🤖 AI CONFIGURATION")
    print("="*60)
    if ai_client:
        if ai_provider == 'groq':
            print("✅ Using: Groq AI (FREE)")
            print("   Model: llama-3.1-70b-versatile")
            print("   Cost: $0.00 (completely free!)")
        elif ai_provider == 'anthropic':
            print("✅ Using: Anthropic Claude")
            print("   Model: claude-sonnet-4")
            print("   Cost: Pay per use")
    else:
        print("❌ No AI configured")
    print("="*60 + "\n")
    
    print("🚀 Starting Serenity Therapy Chatbot...")
    print("📱 Open your browser and go to: http://localhost:5000")
    print("\n💾 Database: serenity.db (persistent storage enabled)")
    print("\nPress CTRL+C to stop the server\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)